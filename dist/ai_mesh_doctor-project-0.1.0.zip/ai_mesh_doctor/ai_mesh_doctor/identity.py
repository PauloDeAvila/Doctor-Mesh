"""Session IDs do not write custom properties to the user's objects."""
from uuid import uuid4
import hashlib
import struct


class IdentityRegistry:
    def __init__(self):
        self._ids = {}

    def get(self, datablock):
        if datablock is None:
            return None
        # session_uid is stable across renames and Blender undo where supported.
        key = (datablock.bl_rna.identifier, getattr(datablock, "session_uid", datablock.as_pointer()))
        if key not in self._ids:
            self._ids[key] = str(uuid4())
        return self._ids[key]


def mesh_fingerprint(mesh) -> str:
    """Every coordinate and connectivity element; no assumptions after topology edits."""
    digest = hashlib.sha256()
    for vertex in mesh.vertices:
        digest.update(struct.pack("<3d", *vertex.co))
    for edge in mesh.edges:
        digest.update(struct.pack("<2I", *edge.vertices))
    for polygon in mesh.polygons:
        digest.update(struct.pack("<I", len(polygon.vertices)))
        for index in polygon.vertices:
            digest.update(struct.pack("<I", index))
    return digest.hexdigest()
