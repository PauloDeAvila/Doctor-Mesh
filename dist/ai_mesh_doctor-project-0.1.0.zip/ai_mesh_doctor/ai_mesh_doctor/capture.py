"""Disposable diagnostic scene: never changes the user's render settings or materials."""
from dataclasses import dataclass
import math
from pathlib import Path
from uuid import uuid4
import bpy
from mathutils import Vector
from .reporting import atomic_json, utc_now


@dataclass(frozen=True)
class CaptureConfig:
    width: int = 960
    height: int = 540
    step_degrees: int = 15
    max_images: int = 128
    wireframe: bool = False
    max_total_vertices: int = 2_000_000

    def __post_init__(self):
        if not 64 <= self.width <= 1920 or not 64 <= self.height <= 1080:
            raise ValueError("Diagnostic capture resolution outside budget")
        if self.step_degrees < 5 or 360 % self.step_degrees:
            raise ValueError("Step must divide 360 and be at least 5 degrees")


def view_schedule(step=15):
    """Directions are Blender world axes; no unsupported anatomical front inference."""
    views = [(name, Vector(direction), "ORTHO") for name, direction in (
        ("axis_pos_x", (1,0,0)), ("axis_neg_x", (-1,0,0)),
        ("axis_pos_y", (0,1,0)), ("axis_neg_y", (0,-1,0)),
        ("top", (0,0,1)), ("bottom", (0,0,-1)))]
    for orbit in ("horizontal", "vertical"):
        for angle in range(0, 360, step):
            r = math.radians(angle)
            direction = (math.cos(r), math.sin(r), 0) if orbit == "horizontal" else (math.cos(r), 0, math.sin(r))
            views.append((f"{orbit}_{angle:03}", Vector(direction), "PERSP"))
    for x in (-1,1):
        for y in (-1,1):
            for z in (-1,1):
                views.append((f"diagonal_{x}_{y}_{z}", Vector((x,y,z)).normalized(), "PERSP"))
    return views


class CaptureSession:
    """One render per step on the main thread, with an ownership manifest.

    Temporary Blender datablocks are released at finish. Exported temporary images
    are retained for review and removed only by cleanup_approved().
    """
    def __init__(self, context, target, directory, config=None):
        self.config = config or CaptureConfig()
        if context.mode != "OBJECT" or target.type != "MESH":
            raise ValueError("Select one mesh in Object Mode")
        self.owner = str(uuid4())
        self.directory = Path(directory).resolve()/self.owner
        self.directory.mkdir(parents=True, exist_ok=False)
        self.manifest_path = self.directory/"manifest.json"
        self.scene = None
        self.objects = []
        self.meshes = []
        self.cameras = []
        self.jobs = []
        self.position = 0
        self.manifest = {"schema_version": "1.0.0", "owner": self.owner, "target": target.name_full,
                         "created_at": utc_now(), "status": "running", "reviewed": False,
                         "approval": "pending", "files": [], "temporary_datablocks_released": False,
                         "coverage": "Sampled external views; occluded/internal surfaces need targeted inspection"}
        try:
            self._prepare(context, target)
        except Exception:
            self.finish(cancelled=True)
            raise

    def _prepare(self, context, target):
        self.scene = bpy.data.scenes.new(f"MD_CAPTURE_{self.owner}")
        self.scene["mesh_doctor_owner"] = self.owner
        scene = self.scene
        scene.render.engine = "BLENDER_WORKBENCH"
        scene.render.resolution_x = self.config.width
        scene.render.resolution_y = self.config.height
        scene.render.resolution_percentage = 100
        scene.render.image_settings.file_format = "PNG"
        scene.render.image_settings.color_depth = "16"
        scene.render.film_transparent = False
        scene.display.shading.light = "STUDIO"
        scene.display.shading.color_type = "SINGLE"
        scene.display.shading.single_color = (0.55, 0.58, 0.62)
        scene.display.shading.show_shadows = True
        scene.display.shading.show_cavity = True
        scene.display.shading.background_type = "WORLD"
        scene.display.shading.background_color = (0.07, 0.07, 0.07)
        scene.display.shading.show_object_outline = self.config.wireframe
        try:
            scene.view_settings.view_transform = "Filmic"
        except TypeError:
            pass
        depsgraph = context.evaluated_depsgraph_get()
        copied_vertices = 0
        for original in context.scene.objects:
            if original.type != "MESH" or (original != target and not original.visible_get()):
                continue
            if original != target and (target.get("mesh_doctor_source") == original.name_full or original.get("mesh_doctor_source") == target.name_full):
                continue
            evaluated = original.evaluated_get(depsgraph)
            copied_vertices += len(evaluated.data.vertices)
            if copied_vertices > self.config.max_total_vertices:
                raise ValueError("Capture scene exceeds vertex budget; isolate a smaller assembly")
            mesh = bpy.data.meshes.new_from_object(evaluated, preserve_all_data_layers=False, depsgraph=depsgraph)
            self.meshes.append(mesh)
            obj = bpy.data.objects.new(original.name_full, mesh)
            obj.matrix_world = evaluated.matrix_world.copy()
            obj["mesh_doctor_owner"] = self.owner
            obj.show_wire = self.config.wireframe
            obj.show_all_edges = self.config.wireframe
            # Workbench has an outline but does not guarantee a full wire render.
            scene.collection.objects.link(obj)
            self.objects.append(obj)
            if original == target:
                self.target = obj
        if not hasattr(self, "target"):
            raise ValueError("Target unavailable")
        bounds = [self.target.matrix_world @ Vector(p) for p in self.target.bound_box]
        self.center = sum(bounds, Vector())/8
        self.radius = max((p-self.center).length for p in bounds)
        if self.radius <= 1e-10:
            raise ValueError("Target has no measurable extent")
        data = bpy.data.cameras.new(f"MD_CAMERA_{self.owner}")
        self.cameras.append(data)
        camera = bpy.data.objects.new(data.name, data)
        camera["mesh_doctor_owner"] = self.owner
        scene.collection.objects.link(camera)
        self.objects.append(camera)
        scene.camera = camera
        data.lens = 50
        data.dof.use_dof = False
        data.clip_start = max(1e-6, self.radius/1000)
        data.clip_end = self.radius*100
        schedule = view_schedule(self.config.step_degrees)
        self.jobs = [(mode, view) for mode in ("isolated", "assembled") for view in schedule]
        if len(self.jobs) > self.config.max_images:
            raise ValueError(f"Full coverage needs {len(self.jobs)} images; raise budget or select a coarser step")
        self.manifest["expected_images"] = len(self.jobs)
        if self.config.wireframe:
            for obj in self.objects:
                if obj.type == "MESH":
                    modifier = obj.modifiers.new("Inspection wireframe", "WIREFRAME")
                    modifier.thickness = self.radius*0.003
                    modifier.use_replace = True
                    modifier.use_boundary = True
        self.manifest["wireframe"] = self.config.wireframe

    def step(self):
        if self.position >= len(self.jobs):
            return False
        mode, (label, direction, projection) = self.jobs[self.position]
        self.position += 1
        scene = self.scene
        for obj in self.objects:
            if obj.type == "MESH":
                obj.hide_render = mode == "isolated" and obj != self.target
        camera = scene.camera
        camera.data.type = projection
        aspect = self.config.width/self.config.height
        # Bounding sphere with a margin bounds every orientation, including long parts.
        camera.data.ortho_scale = 2*self.radius*1.15*max(1, aspect)
        half_fov = min(camera.data.angle_x, camera.data.angle_y)/2
        distance = self.radius/max(0.01, math.sin(half_fov))*1.2
        camera.location = self.center + direction.normalized()*distance
        camera.rotation_euler = (self.center-camera.location).to_track_quat("-Z", "Y").to_euler()
        path = self.directory/f"{mode}_{label}.png"
        scene.render.filepath = str(path)
        bpy.ops.render.render(write_still=True, scene=scene.name)
        if not path.is_file():
            raise RuntimeError("Blender did not produce the requested capture")
        self.manifest["files"].append({"path": str(path), "classification": "temporary_inspection",
                                       "purpose": f"{mode}:{label}", "projection": projection,
                                       "camera_position": list(camera.location), "direction": list(direction),
                                       "center": list(self.center), "radius": self.radius})
        atomic_json(self.manifest_path, self.manifest)
        return self.position < len(self.jobs)

    def finish(self, cancelled=False):
        for obj in self.objects:
            if obj.name in bpy.data.objects:
                bpy.data.objects.remove(obj, do_unlink=True)
        if self.scene and self.scene.name in bpy.data.scenes:
            bpy.data.scenes.remove(self.scene)
        for mesh in self.meshes:
            if mesh.users == 0:
                bpy.data.meshes.remove(mesh)
        for camera in self.cameras:
            if camera.users == 0:
                bpy.data.cameras.remove(camera)
        self.manifest["temporary_datablocks_released"] = True
        self.manifest["status"] = "cancelled" if cancelled else "complete"
        atomic_json(self.manifest_path, self.manifest)
        return self.manifest


def cleanup_approved(manifest_path, explicit_approval=False):
    import json
    if not explicit_approval:
        raise ValueError("Explicit scope approval required before image cleanup")
    manifest_path = Path(manifest_path).resolve()
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest["status"] != "complete" or manifest_path.parent.name != manifest["owner"]:
        raise ValueError("Incomplete or unowned capture scope")
    root = manifest_path.parent
    for entry in manifest["files"]:
        path = Path(entry["path"]).resolve()
        if path.parent != root or path.suffix != ".png" or entry["classification"] != "temporary_inspection":
            raise ValueError("File outside owned inspection scope")
    for entry in manifest["files"]:
        Path(entry["path"]).unlink(missing_ok=True)
        entry["removed_after_approval"] = True
    manifest["approval"] = "approved"
    manifest["cleaned_at"] = utc_now()
    atomic_json(manifest_path, manifest)
    return manifest
