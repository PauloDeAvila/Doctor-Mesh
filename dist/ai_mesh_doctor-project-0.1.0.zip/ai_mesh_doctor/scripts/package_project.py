"""Portable source + demo + compact evidence; no credentials, caches or vendored SDK."""
from pathlib import Path
import zipfile
import hashlib
import json
root = Path(__file__).resolve().parents[1]
output = root/"dist/ai_mesh_doctor-project-0.1.0.zip"
output.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(root)
        if any(p in {"dist", "__pycache__", "runtime", "captures"} for p in relative.parts):
            continue
        if path.suffix.lower() not in {".py", ".md", ".json", ".ps1", ".txt", ".blend", ".log"} and path.name != ".gitignore":
            continue
        archive.write(path, Path("ai_mesh_doctor")/relative)
manifest = {"project_zip": str(output), "project_sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
            "addon_zip": str(root/"dist/ai_mesh_doctor-0.1.0.zip"),
            "addon_sha256": hashlib.sha256((root/"dist/ai_mesh_doctor-0.1.0.zip").read_bytes()).hexdigest()}
(root/"dist/SHA256.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
print(output)
