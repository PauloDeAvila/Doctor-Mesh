from pathlib import Path
import zipfile
root = Path(__file__).resolve().parents[1]
output = root / "dist/ai_mesh_doctor-0.1.0.zip"
output.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
    for path in sorted((root/"ai_mesh_doctor").rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts:
            archive.write(path, path.relative_to(root))
print(output)
